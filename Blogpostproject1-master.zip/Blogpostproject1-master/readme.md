This prject is a basic blog built with Django, Tailwind CSS, ect with some features, eg; search bar, drop down menu and more. It's my first project, so go easy on me. I hope you like it. :) 
